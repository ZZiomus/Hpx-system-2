import React from "react";

const HeroSection = () => {
  return (
    <>
      {" "}
      <div className="heroSectionwrapper">
        <div className="heroSectionline"></div>
        <h2 className="heroSectiontitle">
          Your friend just invited you to join. <br className="heroSectionbr" />{" "}
          Hpx love <span className="heroSectionlove">💕</span> program as a
          referrer
        </h2>
      </div>
    </>
  );
};

export default HeroSection;
