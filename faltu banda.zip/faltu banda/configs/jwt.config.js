module.exports = {
  jwtSecretKey: "longlonglonglongsecret",
};
