module.exports = {
  User: require("./user"),
  ReferalCode: require("./referalCode"),
};
